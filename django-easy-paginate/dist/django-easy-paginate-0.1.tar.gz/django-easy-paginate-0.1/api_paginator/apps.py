from django.apps import AppConfig


class PaginatorConfig(AppConfig):
    name = 'paginator'
